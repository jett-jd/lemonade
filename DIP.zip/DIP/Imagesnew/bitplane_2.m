clc;
clf;
image=imread('F:\DIP\Imagesnew\5.jpg');  

f=image;
[row,col,byt]= size(f);
img7 = double(bitand(f,2^7));
img6 = double(bitand(f,2^6));
img5 = double(bitand(f,2^5)); 
img4 = double(bitand(f,2^4));
img3 = double(bitand(f,2^3));
img2 = double(bitand(f,2^2));
img1 = double(bitand(f,2^1)); 
img0 = double(bitand(f,2^0));
 
figure(1);
subplot(2,2,1); imshow(img7); title('Bit-plane 7');
subplot(2,2,2); imshow(img6); title('Bit-plane 6');
subplot(2,2,3); imshow(img5); title('Bit-plane 5');
subplot(2,2,4); imshow(img4); title('Bit-plane 4');
figure(2);
subplot(2,2,1); imshow(img3); title('Bit-plane 3');
subplot(2,2,2); imshow(img2); title('Bit-plane 2');
subplot(2,2,3); imshow(img1); title('Bit-plane 1');
subplot(2,2,4); imshow(img0); title('Bit-plane 0');