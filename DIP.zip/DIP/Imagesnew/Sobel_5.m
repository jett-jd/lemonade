%%Matlab code for Edge Detection using Sobel Operator:
%Matlab Code
clc;
close all;
 
I = im2double(imread('E:\Pendrive data\Image Processing\Imagesnew\22.jpg'));
I1=im2bw(I);
f=double(I1(:,:,1));
[r c]=size(f);
%% Display image
% Defining Sobel operator
soba = [-1 -2 -1; 0 0 0; 1 2 1];
sobb = [-1 0 1; -2 0 2; -1 0 1];
 
a1=conv2(f,soba,'same');
a2=conv2(f,sobb,'same');

a = a1 + a2;
figure();
subplot(2,2,1);imshow(f);title('original Image');
subplot(2,2,2);imshow(a1);title('edges in horizontal direction');
subplot(2,2,3);imshow(a2);title('edges in vertical direction');
subplot(2,2,4);imshow(a);title('sobel operator');
