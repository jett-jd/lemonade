%Matlab Code
clear all; close all;
img = imread('E:\Pendrive data\Image Processing\Imagesnew\22.jpg');
if(size(img,3) > 1)
    img = rgb2gray(img);
end;
img2 = im2double(img);
h = ones(5,5)/(5^2);
img2 = conv2(img2,h);
img3 = medfilt2(im2double(img),[5 5]);
figure;
subplot(1,3,1); imshow(img); title('Original Circuit Board Image');
subplot(1,3,2); imshow(img2); title('Image after 3x3 Smoothing Filter');
subplot(1,3,3); imshow(img3); title('Image after 3x3 Median Filter');
