%% image Negation Transformation 
clc;
clf;
im=imread('C:\Users\SIT\Desktop\DIP\Imagesnew\4.jpg')
L=255;
s=L-im;
figure(1);
subplot(2,1,1);imshow(im);
subplot(2,1,2);imshow(s);