clear all ;
clc;
p=imread('F:\DIP\Imagesnew\5.jpg');
z=double(p);
y=double(p);
[row,col]=size(z);
%Intensity level slicing with background%
for i=1:1:row
      for j=1:1:col
           if((z(i,j)>50)) && (z(i,j)<100)
                 z(i,j)=255;
           else
                 z(i,j)=p(i,j);
           end
      end
end
%Intensity level slicing without background%
for i=1:1:row
     for j=1:1:col
          if((y(i,j)>50)) && (y(i,j)<100)
               y(i,j)=255;
         else
               y(i,j)=0;
         end
    end
end

figure,
  subplot(1,3,1);  imshow(p);   title('original image');
  subplot(1,3,2);  imshow(uint8(z));   title('Gray Level Slicing With Background');
  subplot(1,3,3);  imshow(uint8(y));   title('Gray Level Slicing Without Background');


            