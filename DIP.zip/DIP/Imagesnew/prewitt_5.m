%%Matlab code for Edge Detection using Prewitt Operator

%% Read image
clear all;
clc;
close all;
                           
I = im2double(imread('E:\Pendrive data\Image Processing\Imagesnew\22.jpg'));
I1=im2bw(I);
f=double(I1(:,:,1));
[r c]=size(f);

%% Display image
 % Prewitt edge detector
gx=[-1 -1 -1;0 0 0 ;1 1 1 ];
gy=[-1 0 1; -1 0 1; -1 0 1];
a1=conv2(f,gx,'same');
a2=conv2(f,gy,'same');
a=a1+a2;
figure();
subplot(2,2,1);imshow(f);title('original Image');
subplot(2,2,2);imshow(a1);title('edges in horizontal direction');
subplot(2,2,3);imshow(a2);title('edges in vertical direction');
subplot(2,2,4);imshow(a);title('prewitt operator');

