% Matlab code to convert RGB to YIQ color Model
clear all;
close all;
clc;
clf;
im=imread('E:\Pendrive data\Image Processing\Imagesnew\37.jpg');

[row col dim]=size(im);
red=im(:,:,1);
green=im(:,:,2);
blue=im(:,:,3);


Y=(0.30*red)+(0.59*green)+(0.11*blue);
I=(0.60*red)+(-0.28*green)+(-0.32*blue);
Q=(0.21*red)+(-0.52*green)+(0.31*blue);


im2=rgb2ntsc(im);
Y1=im2(:,:,1);
I1=im2(:,:,2);
Q1=im2(:,:,3);

plane=zeros(row,col);
Y2=cat(3,Y1,plane,plane);
I2=cat(3,plane,I1,plane);
Q2=cat(3,plane,plane,Q1);

figure(1)
subplot(2,2,1);imshow(im);title('Original Image');
subplot(2,2,2);imshow(Y);title('Y Plane');
subplot(2,2,3);imshow(I);title('I Plane');
subplot(2,2,4);imshow(Q);title('Q Plane');


figure(2)
subplot(2,2,1);imshow(im2);title('YIQ Image');
subplot(2,2,2);imshow(Y1);title('Y1 Plane ');
subplot(2,2,3);imshow(I1);title('I1 Plane');
subplot(2,2,4);imshow(Q1);title('Q1 Plane');

figure(3)
subplot(2,2,1);imshow(im2);title('YIQ Image');
subplot(2,2,2);imshow(Y2);title('Y2 Plane ');
subplot(2,2,3);imshow(I2);title('I2 Plane');
subplot(2,2,4);imshow(Q2);title('Q2 Plane');
