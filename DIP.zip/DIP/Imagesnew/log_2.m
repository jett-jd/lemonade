
clc; 
    clear all;
    close all;
    f=imread('F:\DIP\Imagesnew\5.jpg');
    g=rgb2gray(f);
    c=input('Enter the constant value, c = ');
    [M,N]=size(g);
        for x = 1:M
            for y = 1:N
                m=double(g(x,y));
                z(x,y)=c.*log10(1+m); %use c=0.4
            end
        end
   figure(1)
   subplot(1,2,1);  imshow(f);   title('original image');
   subplot(1,2,2);  imshow(z);   title('Log tranformation image');
