 clc; 
  clear all;
  close all;
  image=imread('E:\Pendrive data\Image Processing\Imagesnew\8.jpg');
  figure;
  imshow(image);
  im = im2double(image);
  [row col] = size(im);
  c = 1; 
  gamma = 2;
  gamma1=.4
  im1=c*power(im,gamma);% gives power law transformation
  im2=c*power(im,gamma1);
  figure,
  subplot(1,3,1);  imshow(image);   title('original image');
  subplot(1,3,2);  imshow(im1);   title(' Power law transfomation gamma=2');
  subplot(1,3,3);  imshow(im2);   title(' Power law transfomation gamma=0.4');