% Matlab code to convert RGB to CMYK color Model
clear all;
close all;
clc;
clf;
im=imread('E:\Pendrive data\Image Processing\Imagesnew\36.jpg');

[row col dim]=size(im);
red=im(:,:,1);
green=im(:,:,2);
blue=im(:,:,3);
   
C=255-red;
M=255-green;
Y=255-blue;

im2=imcomplement(im);
C1=im2(:,:,1);
M1=im2(:,:,2);
Y1=im2(:,:,3);

plane=zeros(row,col);
C2=cat(3,C1,plane,plane);
M2=cat(3,plane,M1,plane);
Y2=cat(3,plane,plane,Y1);

figure(1)
subplot(2,2,1);imshow(im);title('Original Image');
subplot(2,2,2);imshow(C);title('C Plane');
subplot(2,2,3);imshow(M);title('M Plane');
subplot(2,2,4);imshow(Y);title('Y Plane');
figure(2)
subplot(2,2,1);imshow(im2);title('CMYK Image');
subplot(2,2,2);imshow(C1);title('C1 Plane ');
subplot(2,2,3);imshow(M1);title('M1 Plane');
subplot(2,2,4);imshow(Y1);title('Y1 Plane');

figure(3)
subplot(2,2,1);imshow(im);title('Original Image');
subplot(2,2,2);imshow(C2);title('C2 ');
subplot(2,2,3);imshow(M2);title('M2');
subplot(2,2,4);imshow(Y2);title('Y2');


