clear all; 
close all;
clc;
b=imread('E:\Pendrive data\Image Processing\Imagesnew\29.jpg');
a=im2bw(b);
s=strel('line',5,90)
% Dilation, Erosion, Opening , Closing
 
d1=imdilate(a,s);%Dilation 
d2=imerode(a,s);% Erosion
d3=imopen(a,s);%Opening
d4=imclose(a,s);%Closing
%  
% %Hit or Miss Transform, Region Filling, Skeletonization, Thining ,Thickning
%  
s1=[1 0 0;0 1 1;0 1 0];
s2=[0 1 0;0 0 0; 1 0 0];
 d5=bwhitmiss(a,s1,s2);% HIT n Miss Transform
d6=imfill(a,'holes');%Region Filling
 d7 = bwmorph(a,'skel',Inf);%Skeletanization 
 d8=bwmorph(a,'thin',Inf);% Thining
 d9=bwmorph(a,'thicken');% Thickening
%  
% % Boundary Detection
%  
d10=a-d2;% Boundary Detection Type1
 d11=d1-a;% Boundary Detection Type1
 d12=d1-d2;% Boundary Detection Type1

% Displaying All Images

figure(1);
imshow(a);title('original Image');

figure(2);
subplot(2,1,1);imshow(d1);title('Dilated Image');
subplot(2,1,2);imshow(d2);title('Eroded Image');
 figure(3);
 subplot(2,1,1);imshow(d3);title('Opening ');
 subplot(2,1,2);imshow(d4);title('Closing ');
figure(4);
subplot(2,1,1);imshow(d5);title('Hit or Miss transform ');
 subplot(2,1,2);imshow(d6);title('Region filling');
figure(5);
 subplot(2,1,1);imshow(d7);title('Skeletonization');
 subplot(2,1,2);imshow(d8);title('Thinning');
figure(6);
 subplot(2,1,1);imshow(d9);title('Thickening');
 subplot(2,1,2);imshow(d10);title('Boundary detection Type1');
figure(7);
 subplot(2,1,1);imshow(d11);title('Boundary detection Type2');
 subplot(2,1,2);imshow(d12);title('Boundary detection Type3');
