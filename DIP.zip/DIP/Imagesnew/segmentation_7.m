clear all;
close all;
clc;
im=imread('E:\Pendrive data\Image Processing\Imagesnew\25.jpg');
im=rgb2gray(im);
figure(1);imshow(im);title('Original Image');
[row col]=size(im);
x=row/2;
y=col/2;
%*********************Global Thresholding***********************
[X,Y]=ginput(1)
for n=1:1:row
    for m=1:1:col
        q(n,m)=im(n,m);
    end
end
for n=1:1:row
    for m=1:1:col
        if  q(n,m)<X
            q(n,m)=0;
        else
            q(n,m)=255;
        end
    end
end
figure(2);imshow(uint8(q));title('Global Thresholded image');
% % %***************for first small block**************
for n=1:1:x
    for m=1:1:y
        a(n,m)=im(n,m);
    end
end
figure(3);imshow(a);title('1st block');
 
[X,Y]=ginput(1)
for n=1:1:x
    for m=1:1:y
        if  a(n,m)<X
            a(n,m)=0;
        else
            a(n,m)=255;
        end
    end
end
 
% %**********************for 2nd  small block************************
for n=1:1:x
    for m=y+1:1:col
        b(n,m-y)=im(n,m);
    end
end
figure(4);imshow(b);title('2nd block');
 
[X,Y]=ginput(1)
for n=1:1:x
    for m=1:1:y
        if  b(n,m)<X
            b(n,m)=0;
        else
            b(n,m)=255;
        end
    end
end
 
%************************for 3rd  small block**************************
 
for n=x+1:1:row
    for m=1:1:y
        c(n-x,m)=im(n,m);
    end
end
figure(5);imshow(c);title('3rd block');
% c=c+1;
[X,Y]=ginput(1)
for n=1:1:x
    for m=1:1:y
        if  c(n,m)<X
            c(n,m)=0;
        else
            c(n,m)=255;
        end
    end
end
 
% %***********************for 4th small block*****************************
for n=x+1:1:row
    for m=y+1:1:col
        d(n-x,m-y)=im(n,m);
    end
end
figure(6);imshow(d);title('4th block');
% d=d+1;
[X,Y]=ginput(1)
 
for n=1:1:x
    for m=1:1:y
        if  d(n,m)<X
            d(n,m)=0;
        else
            d(n,m)=255;
        end
    end
end
 
s=[a b;c d];
figure(7);
subplot(1,2,1);imshow(uint8(q));title('Global Thresholded image');
subplot(1,2,2);imshow(uint8(s));title('Local Thresholded image');
