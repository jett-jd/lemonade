%program to read the given image,to find mirror image, to display the image
clear all;
close all;
clc;
clf;
im = imread('C:\Users\SIT\Desktop\DIP\Imagesnew\1.jpg');
[row col byt]=size(im)
%iminfo('C:\Users\Administrator\Desktop\Images\1.jpg');
figure(1);imshow(im);title('original image');
for i=1:1:row
    k=1;
    
    for j=col:-1:1
        temp(i,k)=im(i,j);
        new(i,k)=temp(i,k);
        im(i,j)=new(i,k);
        k=k+1;
    end
end
figure(2);subplot(1,2,1);imshow(uint8(im));title('original image');
subplot(1,2,2);imshow(uint8(new));title('mirror image');
% to flip the image
for m=1:1:col
    n=1;
    for p=row:-1:1
        temp(n,m)=im(p,m);
        new(n,m)=temp(n,m);
        im(p,m)=new(n,m);
        n=n+1;
    end
end
figure(3);subplot(2,1,1);imshow(uint8(im));title('original image');
subplot(2,1,2);imshow(uint8(new));title('flip image');

im3= imread('C:\Users\SIT\Desktop\DIP\Imagesnew\1.jpg');
disp('output of whos command')
whos im3
disp('output of imfinfo command')
imfinfo('C:\Users\SIT\Desktop\DIP\Imagesnew\2.jpg')
im4=imadd(im3,100);
im5=imsubtract(im3,100);
figure(4);subplot(1,3,1);imshow(im3);title('original image');
subplot(1,3,2);imshow(im4);title(' image1');
subplot(1,3,3);imshow(im5);title(' image2');
