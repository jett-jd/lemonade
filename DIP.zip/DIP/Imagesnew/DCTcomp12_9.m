clear all;
close all;
clc;
clf;
x1=imread('E:\Pendrive data\Image Processing\Imagesnew\3.jpg');
x=rgb2gray(x1);
x=double(x);
[M N]=size(x);
const=sqrt(2/N);
for u=0:1:N-1
    for v=0:1:N-1
        if u==0
            c(u+1,v+1)=1/sqrt(N);
        else
            a=2*v;
          c(u+1,v+1)=const*cos((pi*(a+1)*u)/(2*N));
        end
    end
end
 final_dct = c*x*c';

dct_1=dct2(x);
figure(1)
subplot(2,1,1);imshow(x1);title('Original Image');
subplot(2,1,2);imshow(final_dct);title('DCT Compressed Image');
figure(2)
imshow(dct_1);title('DCT Image');

            
            