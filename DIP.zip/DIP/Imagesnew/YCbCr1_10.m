 % Matlab code to convert RGB to YCbCr color Model
clear all;
close all;
clc;
clf;
im=imread('F:\DIP\Imagesnew\36.jpg');

[row col dim]=size(im);
red=im(:,:,1);
green=im(:,:,2);
blue=im(:,:,3);

Y=16+((0.257*red)+(0.504*green)+(0.098*blue));
Cb=128+((-0.1148*red)+(-0.291*green)+(0.439*blue));
Cr=128+((0.439*red)+(-0.368*green)+(-0.071*blue));


im2=rgb2ycbcr(im);
Y1=im2(:,:,1);
Cb1=im2(:,:,2);
Cr1=im2(:,:,3);


plane=zeros(row,col);
Y2=cat(3,Y1,plane,plane);
Cb2=cat(3,plane,Cb1,plane);
Cr2=cat(3,plane,plane,Cr1);

figure(1)
subplot(2,2,1);imshow(im);title('Original Image');
subplot(2,2,2);imshow(Y);title('Y Plane');
subplot(2,2,3);imshow(Cb);title('Cb Plane');
subplot(2,2,4);imshow(Cr);title('Cr Plane');


figure(2)
subplot(2,2,1);imshow(im2);title('YCrCb Image');
subplot(2,2,2);imshow(Y1);title('Y1 Plane ');
subplot(2,2,3);imshow(Cb1);title('Cb1 Plane');
subplot(2,2,4);imshow(Cr1);title('Cr1 Plane');

figure(3)
subplot(2,2,1);imshow(im);title('Original Image');
subplot(2,2,2);imshow(Y2);title('Y2 Plane');
subplot(2,2,3);imshow(Cb2);title('Cb2 Plane');
subplot(2,2,4);imshow(Cr2);title('Cr2 Plane');

