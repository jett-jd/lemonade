% Matlab code for RGB color Model
clear all;
close all;
clc;
clf;
im=imread('E:\Pendrive data\Image Processing\Imagesnew\33.jpg');

[row col dim]=size(im);
red=im(:,:,1);
green=im(:,:,2);
blue=im(:,:,3);
plane=zeros(row,col);
RED=cat(3,red,plane,plane);
GREEN=cat(3,plane,green,plane);
BLUE=cat(3,plane,plane,blue);
figure(1)
subplot(2,2,1);imshow(im);title('Original Image');
subplot(2,2,2);imshow(red);title('Red Plane');
subplot(2,2,3);imshow(green);title('Green Plane');
subplot(2,2,4);imshow(blue);title('Blue Plane');
figure(2)
subplot(2,2,1);imshow(im);title('Original Image');
subplot(2,2,2);imshow(RED);title('Red ');
subplot(2,2,3);imshow(GREEN);title('Green');
subplot(2,2,4);imshow(BLUE);title('Blue');

