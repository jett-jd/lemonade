clear all;
close all;
clc;
clf;
x=imread('E:\Pendrive data\Image Processing\Imagesnew\3.jpg');
x=rgb2gray(x);
x=double(x);
[row col]=size(x);
const=sqrt(row*col);
for n=0:1:row-1
    for k=0:1:col-1
        W(n+1,k+1)=exp(-i*2*pi*n*k/const);
        
    end
end
X = W*x*W.';
ff=fft2(x);
figure(1)
colormap(gray);
imagesc(x);

title('original image');
figure(2)
colormap(gray);
imagesc(fftshift(log(1+abs(X))));

figure(3);
colormap(gray);
imagesc(fftshift(log(1+abs(ff))));
    
            